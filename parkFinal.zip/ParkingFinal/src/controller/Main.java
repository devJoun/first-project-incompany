package controller;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) throws InterruptedException {

	ParkController controller = new ParkController();
	controller.ParkController(); // 주차 관리 컨트롤러
	}
}
