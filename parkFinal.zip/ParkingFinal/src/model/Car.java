package model;

public class Car {
	
	String check;

	public String getCheck() {
		return check;
	}

	public void setCheck(String check) {
		this.check = check;
	}

	public Car(String check) {
		super();
		this.check = check;
	}

	
	
}
